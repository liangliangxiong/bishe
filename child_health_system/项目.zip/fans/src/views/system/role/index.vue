<template>
  <div class="role-manage-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>角色管理</span>
          <h1>用户管理页面已实现该功能。</h1>
        </div>
      </template>
      <!-- 在这里添加具体的页面内容 -->
    </el-card>
  </div>
</template>

<script setup>
// 组件逻辑写在这里
</script>

<style lang="scss" scoped>
.role-manage-container {
  padding: 20px;
  
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style> 