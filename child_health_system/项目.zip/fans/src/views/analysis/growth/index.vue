<template>
  <div class="growth-analysis-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>生长曲线分析</span>
          <span>生长曲线分析</span>
          <span>生长曲线分析</span>
<span>生长曲线分析</span>
        </div>
      </template>
      <!-- 在这里添加具体的页面内容 -->
    </el-card>
  </div>
</template>

<script setup>
// 组件逻辑写在这里
</script>

<style lang="scss" scoped>
.growth-analysis-container {
  padding: 20px;
  
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style> 